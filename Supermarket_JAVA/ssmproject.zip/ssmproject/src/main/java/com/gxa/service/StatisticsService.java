package com.gxa.service;

import java.util.*;

public interface StatisticsService {

     Map<String, Object> getStockChangeListByDateType(int typeCode, int dateCode,int start);

     List<Map<String,Integer>> getStockStatistics();

     Map<String,Integer> getCheckinAndCheckoutStatistics();
}
