package com.gxa.service;

import com.gxa.dto.ResultData;
import com.gxa.pojo.Role;
import io.swagger.models.auth.In;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: tyg
 * Date: 2020/07/18 20:05
 * Version: V1.0
 * Description:
 */
public interface RoleService {
    ResultData listRole();

    ResultData insertRole(String roleName, List<Integer> permissionId);

    ResultData updateRole(List<Integer> permissionIdList, int roleId, String roleName);

    ResultData deleteRole(int roleId);

    ResultData listAllRole();
}
