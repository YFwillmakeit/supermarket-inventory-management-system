package com.gxa.service.impl;

import com.github.pagehelper.PageInfo;
import com.gxa.dto.ResultData;
import com.gxa.mapper.UserMapper;
import com.gxa.pojo.User;
import com.gxa.pojo.UserExample;
import com.gxa.service.UserService;
import com.gxa.utils.Code;
import com.gxa.utils.MD5Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;

    private UserExample userExample = new UserExample();

    @Override
    public ResultData listUser() {
        ResultData<Map> resultData = new ResultData<>();
        UserExample userExample = new UserExample();
        List<User> users = userMapper.listUser();
        //PageInfo<查询到的数据类型> pages = new PageInfo<>(list类型, 页面显示的导航条数);
        PageInfo<User> pages = new PageInfo<>(users, 3);
        HashMap<String, Object> map = new HashMap<>();
        map.put("total", pages.getTotal());
        map.put("pages", pages.getPages());
        map.put("pageNum", pages.getPageNum());
        map.put("userList", pages.getList());
        resultData.setCode(200);
        resultData.setData(map);
        return resultData;
    }

    @Override
    public User findusernamePassword(String username, String password) {
        UserExample userExample = new UserExample();
        userExample.createCriteria().andUsernameEqualTo(username).andPasswordEqualTo(password);
        List<User> users = userMapper.selectByExample(userExample);
        if (users.isEmpty()) {
            return null;
        }
        return users.get(0);
    }

    @Override
    public ResultData insertUser(User user) {
        ResultData resultData = new ResultData();
        UserExample userExample = new UserExample();
        String passwordByMd5 = MD5Util.digest(user.getPassword());
        user.setPassword(passwordByMd5);
        int i = userMapper.insertSelective(user);
        if (i <= 0) {
            resultData.setCode(Code.FALISE);
            resultData.setMsg("添加失败");
        } else {
            resultData.setCode(Code.SUCCESS);
            resultData.setMsg("添加成功");
        }
        return resultData;
    }

    @Override
    public ResultData removeUser(int userId) {
        ResultData resultData = new ResultData();
        User user = new User();
        user.setState(1);
        user.setId(userId);
        int i = userMapper.updateByPrimaryKeySelective(user);
        if (i <= 0) {
            resultData.setCode(Code.FALISE);
            resultData.setMsg("删除失败");
        } else {
            resultData.setCode(Code.SUCCESS);
            resultData.setMsg("删除成功");
        }
        return resultData;
    }

    @Override
    public ResultData removeUserbyIdList(List userIdList) {
        ResultData<Object> resultData = new ResultData<>();
        UserExample userExample = new UserExample();
        userExample.createCriteria().andIdIn(userIdList);
        int i = userMapper.deleteByExample(userExample);
        if (i <= 0) {
            resultData.setCode(Code.FALISE);
            resultData.setMsg("删除失败");
        } else {
            resultData.setCode(Code.SUCCESS);
            resultData.setMsg("成功删除" + i + "条数据");
        }
        return resultData;
    }

    @Override
    public ResultData updateUser(User user) {
        ResultData<Object> resultData = new ResultData<>();
        System.out.println(user);
        String password = user.getPassword();
        if (password != null) {
            user.setPassword(MD5Util.digest(password));
        }
        int i = userMapper.updateByPrimaryKeySelective(user);
        if (i <= 0) {
            resultData.setCode(Code.FALISE);
            resultData.setMsg("修改失败");
        } else {
            resultData.setCode(Code.SUCCESS);
            resultData.setMsg("修改成功");
        }
        return resultData;
    }

    @Override
    public ResultData searchUser(User user) {

        ResultData<Object> resultData = new ResultData<>();
        UserExample userExample = new UserExample();
        UserExample.Criteria criteria = userExample.createCriteria();
        if (user.getUsername() != null) {
            criteria.andUsernameLike("%" + user.getUsername() + "%");
        }
        UserExample.Criteria criteria1 = userExample.createCriteria();
        if (user.getRoleId() != null) {
            criteria.andRoleIdEqualTo(user.getRoleId());
        }
        List<User> users = userMapper.selectByMyExample(userExample);
        PageInfo<User> pages = new PageInfo<>(users, 3);
        HashMap<String, Object> map = new HashMap<>();
        map.put("total", pages.getTotal());
        map.put("pages", pages.getPages());
        map.put("pageNum", pages.getPageNum());
        map.put("userList", pages.getList());
        resultData.setCode(Code.SUCCESS);
        resultData.setData(map);
        return resultData;
    }
}
