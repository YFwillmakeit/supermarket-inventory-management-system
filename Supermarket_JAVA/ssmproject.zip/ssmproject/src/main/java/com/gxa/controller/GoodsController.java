package com.gxa.controller;

import com.github.pagehelper.PageHelper;
import com.gxa.dto.ResultData;
import com.gxa.service.GoodsService;
import com.gxa.utils.AppDateUtils;
import com.gxa.utils.Code;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import java.text.SimpleDateFormat;
import java.util.Date;

@Api(tags = "商品管理")
@RestController
@Validated
public class GoodsController {

    @Autowired
    private GoodsService goodsService;

    /**
     * 显示商品
     *
     * @param pageNo
     * @return
     */
    @ApiOperation("显示商品")
    @PostMapping("/goods")
    public ResultData showGoods(@RequestParam(defaultValue = "1") Integer pageNo) {
        // ResultData resultData =new ResultData();
        Integer limit = 8;
        PageHelper.startPage(pageNo, limit);
        return goodsService.showGoods();
    }


    /**
     * 增加商品
     *
     * @param goodsName
     * @param name
     * @param goodsDesc
     * @param shelfLife
     * @return
     */
    @ApiOperation("增加商品")
    @GetMapping("/goods/add")
    public ResultData addGoods(String goodsName, String name, String goodsDesc, Integer shelfLife, String productTime) {
        System.out.println("==***************************接收前端增加商品信息==" + "商品名称" + goodsName + "商品类型名称" + name + "商品描述" + goodsDesc + "商品保质期" + shelfLife);
        ResultData<Object> resultData = new ResultData<>();
        Date formatTime = null;
        System.out.println("时间时间时间" + productTime);
        try {
            formatTime = AppDateUtils.toDate(productTime);
            Date date = new Date();
            if (formatTime.after(date)){
                resultData.setCode(Code.FALISE);
                resultData.setMsg("时间选择错误");
            }
        } catch (Exception e) {
            resultData.setCode(Code.FALISE);
            resultData.setMsg("时间格式错误");
            e.printStackTrace();
            return resultData;
        }
        resultData = goodsService.addGoods(goodsName, name, goodsDesc, shelfLife, formatTime);
        return resultData;
    }

    /**
     * 批量删除
     *
     * @param AllId
     * @return
     */
    @ApiOperation("批量删除商品")
    @GetMapping("/goods/selectDelete")
    public ResultData delAllGoods(int[] AllId) {
        System.out.println("==========接收前端批量删除的id==================" + AllId);
        ResultData resultData = new ResultData();
        boolean rs = goodsService.delAllGoods(AllId);
        System.out.println("删除选中商品" + rs);
        if (rs = true) {
            resultData.setCode(Code.SUCCESS);
            resultData.setMsg("商品删除成功");
        } else {
            resultData.setCode(Code.FALISE);
            resultData.setMsg("商品删除失败");
        }
        return resultData;
    }

    /**
     * 删除
     *
     * @param id
     * @return
     */
    @ApiOperation("删除商品")
    @GetMapping("/goods/delete")
    public ResultData delGoods(@RequestParam Integer id) {
        System.out.println("商品id===========" + id);
        ResultData resultData = goodsService.delGoods(id);
        return resultData;
    }


    /**
     * 修改商品
     *
     * @param id
     * @param goodsName
     * @param name
     * @param goodsDesc
     * @param shelfLife
     * @return
     */
    @ApiOperation("修改商品")
    @GetMapping("/goods/update")
    public ResultData editGoods(Integer id, String goodsName, String name, String goodsDesc, Integer shelfLife) {
        System.out.println("==********************************接收前端修改商品信息==" + "商品id" + id + "商品名称" + goodsName + "商品类型名称" + name + "商品描述" + goodsDesc + "商品保质期" + shelfLife);
        ResultData resultData = goodsService.editGoods(id, goodsName, name, goodsDesc, shelfLife);

        return resultData;
    }

    /**
     * 商品搜索
     *
     * @param goodsName
     * @return
     */
    @ApiOperation("搜索商品")
    @GetMapping("/goods/search")
    public ResultData searchGoods(String goodsName) {
        System.out.println("===========搜索商品Controller========================");
        ResultData resultData = goodsService.searchGoods(goodsName);
        Integer pageNo = 1;
        int limit = 3;
        PageHelper.startPage(pageNo, limit);
        System.out.println("=======搜索商品controller===============" + resultData);

        return resultData;
    }

}

