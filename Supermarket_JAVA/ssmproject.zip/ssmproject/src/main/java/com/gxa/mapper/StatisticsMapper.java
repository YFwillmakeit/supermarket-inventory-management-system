package com.gxa.mapper;

import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * 统计的查询接口
 */
public interface StatisticsMapper {

    /**按传入类型（年、月、日 以及出入库类型）的方式查询数据
     * @param dateCode 时间类型
     * @param typeCode 出入库类型
     * @return List<StatisticsStockChangeBean>
     */
    List<Map<String,Object>> getStockChangeListByDateType( @Param("typeCode") int typeCode,@Param("dateCode") int dateCode);

    /**
     *按商品类型统计库存
     * @return
     */
    List<Map<String,Integer>> getStockStatistics();

    /**
     * 统计截止当前时间一周内的出入库总量
     * @return 出库或入库总数
     */
    Integer getCheckStatistics(@Param("typeCode") int typeCode);
}
