package com.gxa.controller;

import com.gxa.dto.ResultData;
import com.gxa.pojo.Goods;
import com.gxa.pojo.Stock;
import com.gxa.pojo.User;
import com.gxa.service.StockService;
import com.gxa.utils.AppDateUtils;
import com.gxa.utils.Code;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Api(tags = "库存管理")
//库存表控制器
@RestController
public class StockController {

    @Autowired
    private StockService stockService;

    private ResultData resultData;

    @ApiOperation("库存管理")
    @ApiImplicitParam(name = "page",value = "页号",required = true,paramType = "int",dataType = "json")
    @PostMapping("/stock")
    public ResultData stock(int page){
        resultData = new ResultData();
        Map<String,Object> map = stockService.stock(page);
        resultData.setCode(Code.SUCCESS);
        resultData.setMsg("查询成功");
        resultData.setData(map);
        return resultData;
    }

    @ApiOperation("搜索库存")
    @ApiImplicitParam(name = "goodsName",value = "商品名",required = true,paramType = "String",dataType = "json")
    @PostMapping("/stock/search")
    public ResultData stockSearch(String goodsName){
       resultData = new ResultData();
       List<Map<String,Object>> mapList = stockService.stockSearch(goodsName);
       if (mapList != null && !mapList.isEmpty()){
           resultData.setCode(Code.SUCCESS);
           resultData.setMsg("查询成功");
           resultData.setData(mapList);
       }else {
           resultData.setCode(Code.FALISE);
           resultData.setMsg("没有该商品的库存数据");
       }
       return resultData;
    }

    @ApiOperation("出库记录")
    @ApiImplicitParam(name = "page",value = "当前页数",required = true,paramType = "int",dataType = "json")
    @PostMapping("/checkout")
    public ResultData checkout(int page){
        resultData = new ResultData();
        Map<String, Object> map = stockService.check(0,page);
        resultData.setCode(Code.SUCCESS);
        resultData.setMsg("查询成功");
        resultData.setData(map);
        return resultData;
    }

    @ApiOperation("搜索出库记录")
    @ApiImplicitParam(name = "goodsName",value = "商品名",required = true,paramType = "String",dataType = "json")
    @PostMapping("/checkoutSearch")
    public ResultData checkoutSearch(String goodsName,int page){
         resultData = new ResultData();
         Map<String,Object> map = stockService.checkSearch(0,goodsName,page);
         if(map != null) {
             resultData.setCode(Code.SUCCESS);
             resultData.setMsg("查询成功");
             resultData.setData(map);
         }else {
             resultData.setCode(Code.FALISE);
             resultData.setMsg("没有该商品的出库记录");
         }
         return resultData;
    }

    @ApiOperation("商品出库")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "map",value = "json对象",required = true)
    })
    @PostMapping("/checkoutAdd")
    public ResultData checkoutAdd(@RequestBody Map<String,String> map, HttpSession httpSession){
        User user = (User) httpSession.getAttribute("user");
        System.out.println(map);
        resultData = new ResultData();
        if (user == null) {
            resultData.setCode(Code.FALISE);
            resultData.setMsg("未登录");
            return resultData;
        }
        int id = user.getId();
        stockService.checkAdd(0,map,id);
        return resultData;
    }

    @ApiOperation("编辑出库记录")
    @ApiImplicitParam(name = "map",value = "json对象",required = true)
    @PostMapping("/checkoutEdit")
    public ResultData checkoutEdit(@RequestBody Map<String,String> map,HttpSession httpSession){
        User user = (User) httpSession.getAttribute("user");
        System.out.println(map);
        resultData = new ResultData();
        if (user == null) {
            resultData.setCode(Code.FALISE);
            resultData.setMsg("未登录");
            return resultData;
        }
        int id = user.getId();
        resultData = new ResultData();
        resultData = stockService.checkEdit(0,map,id);
        return resultData;
    }

    @ApiOperation("出库记录删除")
    @ApiImplicitParam(name = "id",value = "商品id",required = true,paramType = "int",dataType = "json")
    @PostMapping("/checkoutDelete")
    public ResultData checkoutDelete(int id,HttpSession httpSession){
        User user = (User) httpSession.getAttribute("user");
        resultData = new ResultData();
        if (user == null) {
            resultData.setCode(Code.FALISE);
            resultData.setMsg("未登录");
            return resultData;
        }
        stockService.checkDelete(id,user.getId());
        return resultData;
    }

    @ApiOperation("入库记录")
    @ApiImplicitParam(name = "page",value = "当前页数",required = true,paramType = "int",dataType = "json")
    @PostMapping("/checkin")
    public ResultData checkin(int page){
        resultData = new ResultData();
        Map<String,Object> map = stockService.check(1,page);
        resultData.setCode(Code.SUCCESS);
        resultData.setMsg("查询成功");
        resultData.setData(map);
        return resultData;
    }

    @ApiOperation("搜索入库记录")
//    @ApiImplicitParam(name = "goodsName",value = "商品名",required = true,paramType = "String",dataType = "json")
    @PostMapping("/checkinSearch")
    public ResultData checkinSearch(String goodsName,int page){
//    public ResultData checkinSearch(String[] params){
        resultData = new ResultData();
        Map<String,Object> map = stockService.checkSearch(1,goodsName,page);
//        Map<String,Object> map = stockService.checkSearch(1,params[0],Integer.parseInt(params[1]));
        System.out.println(map);
        if(map != null) {
            resultData.setCode(Code.SUCCESS);
            resultData.setMsg("查询成功");
            resultData.setData(map);
        }else {
            resultData.setCode(Code.FALISE);
            resultData.setMsg("没有该商品的入库记录");
        }
        return resultData;
    }

    @ApiOperation("商品入库")
    @ApiImplicitParam(name = "map",value = "json对象",required = true)
    @PostMapping("/checkinAdd")
    public ResultData checkinAdd(@RequestBody Map<String,String> map,HttpSession httpSession){
        User user = (User) httpSession.getAttribute("user");
        System.out.println(user);
        System.out.println(map);
        resultData = new ResultData();
        if (user == null) {
            resultData.setCode(Code.FALISE);
            resultData.setMsg("未登录");
            return resultData;
        }
        int id = user.getId();
        System.out.println(map);
        resultData = new ResultData();
        resultData = stockService.checkAdd(1,map,id);
        return resultData;
    }
    @ApiOperation("编辑入库记录")
    @ApiImplicitParam(name = "map",value = "json对象",required = true)
    @PostMapping("/checkinEdit")
    public ResultData checkinEdit(@RequestBody Map<String,String> map,HttpSession httpSession){
        User user = (User) httpSession.getAttribute("user");
        System.out.println(user);
        System.out.println(map);
        resultData = new ResultData();
        if (user == null) {
            resultData.setCode(Code.FALISE);
            resultData.setMsg("未登录");
            return resultData;
        }
        resultData = new ResultData();
        int id = user.getId();
        resultData = stockService.checkEdit(1,map,id);
        return resultData;
    }

    @ApiOperation("入库记录删除")
    @ApiImplicitParam(name = "id",value = "商品id",required = true,paramType = "int",dataType = "json")
    @PostMapping("/checkinDelete")
    public ResultData checkinDelete(int id,HttpSession httpSession){
        User user = (User) httpSession.getAttribute("user");
        System.out.println(user);
        resultData = new ResultData();
        if (user == null) {
            resultData.setCode(Code.FALISE);
            resultData.setMsg("未登录");
            return resultData;
        }
        stockService.checkDelete(id,user.getId());
        resultData.setCode(Code.SUCCESS);
        resultData.setMsg("删除成功");
        return resultData;
    }
}
