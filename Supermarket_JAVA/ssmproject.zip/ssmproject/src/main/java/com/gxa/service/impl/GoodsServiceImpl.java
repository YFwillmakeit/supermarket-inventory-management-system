package com.gxa.service.impl;

import com.github.pagehelper.PageInfo;
import com.gxa.dto.ResultData;
import com.gxa.mapper.GoodsMapper;
import com.gxa.mapper.GoodsTypeMapper;
import com.gxa.mapper.StockMapper;
import com.gxa.pojo.*;
import com.gxa.service.GoodsService;
import com.gxa.utils.Code;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class GoodsServiceImpl implements GoodsService {

    @Autowired
    private GoodsMapper goodsMapper;
    GoodsExample goodsExample = new GoodsExample();

    @Autowired
    private GoodsTypeMapper goodsTypeMapper;

    @Autowired
    private StockMapper stockMapper;


    /**
     * 显示商品
     *
     * @return
     */
    @Override
    public ResultData showGoods() {
        ResultData<Map> resultData = new ResultData<>();
        List<Map<String, Object>> goodsList;
        goodsList = goodsMapper.showGoods();
        PageInfo<Map<String, Object>> pages = new PageInfo<>(goodsList, 3);
        HashMap<String, Object> map = new HashMap<>();
        map.put("total", pages.getTotal());
        map.put("pages", pages.getPages());
        map.put("pagenum", pages.getPageNum());
        map.put("list", pages.getList());

        resultData.setCode(200);
        resultData.setData(map);
        System.out.println(goodsList);
        return resultData;
    }


    /**
     * 增加商品
     *
     * @param goodsName
     * @param name
     * @param goodsDesc
     * @param shelfLife
     * @return
     */
    @Override
    public ResultData addGoods(String goodsName, String name, String goodsDesc, Integer shelfLife, Date productTime) {
        GoodsTypeExample goodsTypeExample = new GoodsTypeExample();
        goodsTypeExample.createCriteria().andNameEqualTo(name);
        ResultData resultData = null;
        try {
            GoodsExample goodsExample = new GoodsExample();
            goodsExample.createCriteria().andGoodsNameEqualTo(goodsName);
            List<Goods> goodsList = goodsMapper.selectByExample(goodsExample);
            boolean flag = false;
            if (goodsList.isEmpty()) {
                flag = true;
            }

            List<GoodsType> goodsTypes = goodsTypeMapper.selectByExample(goodsTypeExample);
            int typeId = goodsTypes.get(0).getId();
            System.out.println("****************************8插入的商品类型的id" + typeId);

            resultData = new ResultData();
            Goods goods = new Goods();
            goods.setGoodsName(goodsName);
            goods.setGoodsDesc(goodsDesc);
            goods.setShelfLife(shelfLife);
            goods.setTypeId(typeId);
            goods.setProductTime(productTime);

            int i = goodsMapper.myInsertSelective(goods);

            Integer id = goods.getId();
            if (i > 0) {
                if (flag) {
                    Stock stock = new Stock();
                    stock.setGoodsId(id);
                    stock.setGoodsAmount(0);
                    stock.setStandardAmount(typeId * 500);
                    stockMapper.insertSelective(stock);
                }

            } else {
                resultData.setCode(Code.FALISE);
                resultData.setMsg("添加商品库存失败");
            }
        } catch (Exception e) {
            resultData.setCode(Code.FALISE);
            resultData.setMsg("商品增加失败");
            e.printStackTrace();
        }
        resultData.setCode(Code.SUCCESS);
        resultData.setMsg("商品增加成功");
        return resultData;
    }

    /**
     * 删除单个商品
     *
     * @param delId
     * @return
     */
    @Override
    public ResultData delGoods(int delId) {
        Goods goods = new Goods();
        goods.setId(delId);
        goods.setState(1);
        ResultData resultData = new ResultData();
        int rs = goodsMapper.updateByPrimaryKeySelective(goods);
        if (rs > 0) {
            resultData.setCode(Code.SUCCESS);
            resultData.setMsg("商品删除成功");
        } else {
            resultData.setCode(Code.FALISE);
            resultData.setMsg("商品删除失败");
        }
        return resultData;
    }


    /**
     * 编辑商品
     *
     * @param id
     * @param goodsName
     * @param name
     * @param goodsDesc
     * @param shelfLife
     * @return
     */
    @Override
    public ResultData editGoods(Integer id, String goodsName, String name, String goodsDesc, Integer shelfLife) {

        GoodsTypeExample goodsTypeExample = new GoodsTypeExample();
        goodsTypeExample.createCriteria().andNameEqualTo(name);
        List<GoodsType> goodsTypes = goodsTypeMapper.selectByExample(goodsTypeExample);
        GoodsType goodsType = goodsTypes.get(0);
        Goods goods1 = new Goods();
        goods1.setId(id);
        goods1.setGoodsName(goodsName);
        goods1.setGoodsDesc(goodsDesc);
        goods1.setShelfLife(shelfLife);
        goods1.setTypeId(goodsType.getId());
        int rs = goodsMapper.updateByPrimaryKeySelective(goods1);

        ResultData resultData = new ResultData();
        if (rs > 0) {
            resultData.setCode(Code.SUCCESS);
            resultData.setMsg("商品修改成功");
        } else {
            resultData.setCode(Code.FALISE);
            resultData.setMsg("商品修改失败");
        }
        return resultData;
    }

    /**
     * 搜索商品
     *
     * @param goodsName
     * @return
     */
    @Override
    public ResultData searchGoods(String goodsName) {

        ResultData<Map> resultData = new ResultData<>();
        List<Map<String, Object>> goodsList;
        goodsList = goodsMapper.searchGoods(goodsName);
        PageInfo<Map<String, Object>> pages = new PageInfo<>(goodsList, 3);
        HashMap<String, Object> map = new HashMap<>();
        map.put("total", pages.getTotal());
        map.put("pages", pages.getPages());
        map.put("pagenum", pages.getPageNum());
        map.put("list", pages.getList());

        System.out.println(map);
        resultData.setCode(200);
        resultData.setData(map);
        System.out.println("====Service============");
        return resultData;
    }

    /**
     * @param allId
     * @return
     */
    @Override
    public boolean delAllGoods(int[] allId) {
        boolean rs = goodsMapper.delAllGoods(allId);
        return rs;
    }


}
