package com.gxa.service;

import com.gxa.dto.ResultData;
import com.gxa.pojo.Permission;

/**
 * Created with IntelliJ IDEA.
 * User: tyg
 * Date: 2020/07/20 10:11
 * Version: V1.0
 * Description:
 */
public interface PermissionService {
    ResultData listAllPermission();

    ResultData insertPermission(Permission permission);

    ResultData updatePermission(Permission permission);

    ResultData removePermission(int permissionId);
}
