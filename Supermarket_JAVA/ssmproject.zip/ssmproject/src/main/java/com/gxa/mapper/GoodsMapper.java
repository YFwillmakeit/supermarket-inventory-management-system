package com.gxa.mapper;

import com.gxa.pojo.Goods;
import com.gxa.pojo.GoodsExample;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

public interface GoodsMapper {
    long countByExample(GoodsExample example);

    int deleteByExample(GoodsExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(Goods record);

    int insertSelective(Goods record);

    List<Goods> selectByExample(GoodsExample example);

    Goods selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") Goods record, @Param("example") GoodsExample example);

    int updateByExample(@Param("record") Goods record, @Param("example") GoodsExample example);

    int updateByPrimaryKeySelective(Goods record);

    int updateByPrimaryKey(Goods record);

    List<Map<String, Object>> showGoods();

    boolean delAllGoods(@Param("allId") int[] allId);

    List<Map<String, Object>> searchGoods(@Param("goodsName") String goodsName);

    Integer myInsertSelective(Goods record);

    int addGoods(Goods goods);

    int MyInsertSelective(Goods record);
}