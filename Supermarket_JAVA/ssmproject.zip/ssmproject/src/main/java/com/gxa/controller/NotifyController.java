package com.gxa.controller;

import com.github.pagehelper.PageHelper;
import com.gxa.dto.ResultData;
import com.gxa.pojo.StockChange;
import com.gxa.service.StockChangeService;
import com.gxa.service.StockService;
import com.gxa.service.UserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.xml.transform.Result;
import java.util.List;
import java.util.Map;



@Api(tags = "库存不足")
@RestController
public class NotifyController {
    @Autowired
    private StockChangeService stockChangeService;

    /**
     * @param pageNo 页数
     * @return
     */
    @ApiOperation("库存不足")
        @GetMapping("/notify")
        public Map notify1(@RequestParam(defaultValue = "1")int pageNo){
          int limit=10;
          PageHelper.startPage(pageNo,limit);
        return stockChangeService.listgoods();
    }
}
