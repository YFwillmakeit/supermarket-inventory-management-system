package com.gxa.service.impl;

import com.github.pagehelper.PageInfo;
import com.gxa.mapper.StatisticsMapper;
import com.gxa.service.StatisticsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.DateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class StatisticsServiceImpl implements StatisticsService {

    @Autowired(required = false)
    StatisticsMapper statisticsMapper;

    @Override
    public Map<String, Object> getStockChangeListByDateType(int typeCode, int dateCode,int start) {
        List<Map<String,Object>> sscb = statisticsMapper.getStockChangeListByDateType(typeCode, dateCode);
        PageInfo<Map<String,Object>> pageInfo=new PageInfo<>(sscb,3);
        List<Map<String,Object>> list=pageInfo.getList();
        //时间转换字符串，出入库类型转换
        for (int i=0;i<list.size();i++) {
            String formatDate = null;
            formatDate = DateFormat.getDateInstance().format(list.get(i).get("OperateTime"));
            list.get(i).put("OperateTime",formatDate);
            list.get(i).put("outInType",(int)(list.get(i).get("outInType"))==1?"入库":"出库");
        }
        Map<String, Object> map = new HashMap<>();
        map.put("list", list);
        map.put("pages", pageInfo.getPages());
        map.put("total",pageInfo.getTotal());
        map.put("start", pageInfo.getPageNum());


        return map;
    }

    @Override
    public List<Map<String,Integer>> getStockStatistics() {
        return statisticsMapper.getStockStatistics();
    }

    @Override
    public Map<String, Integer> getCheckinAndCheckoutStatistics() {
        Map<String,Integer> map=new HashMap<String, Integer>();
        map.put("checkin",statisticsMapper.getCheckStatistics(1));
        map.put("checkout",statisticsMapper.getCheckStatistics(0));
        return map;
    }
}
