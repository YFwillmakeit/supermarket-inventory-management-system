package com.gxa.controller;

import com.gxa.dto.ResultData;
import com.gxa.pojo.Permission;
import com.gxa.service.PermissionService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

/**
 * Created with IntelliJ IDEA.
 * User: tyg
 * Date: 2020/07/20 10:12
 * Version: V1.0
 * Description:
 */
@Api(tags = "权限表增删查改")
@RestController
public class PermissionController {
    @Autowired
    private PermissionService permissionService;

    @ApiOperation("获取所有权限信息")
    @GetMapping("/permission/show")
    public ResultData showAllPermission(){
        return permissionService.listAllPermission();
    }

    @ApiOperation("添加权限")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "permission", value = "Permission对象{permissionName:}", required = true),
    })
    @PostMapping("/permission/add")
    public ResultData addPermission(@RequestBody Permission permission){
        return permissionService.insertPermission(permission);
    }

    @ApiOperation("修改权限")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "permission", value = "Permission对象{id:,permissionName:}", required = true),
    })
    @PostMapping("/permission/update")
    public ResultData updatePermission(@RequestBody Permission permission){
        return permissionService.updatePermission(permission);
    }

    @ApiOperation("删除权限")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "permissionId", value = "权限ID", required = true),
    })
    @GetMapping("/permission/delete")
    public ResultData removePermission(@RequestParam int permissionId){
        return permissionService.removePermission(permissionId);
    }


}
