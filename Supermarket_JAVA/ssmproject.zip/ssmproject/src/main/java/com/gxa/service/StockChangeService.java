package com.gxa.service;

import java.util.Map;

public interface StockChangeService {



    //查询即将过期商品
    Map<String,Object> listgoods2();
    //
    //查询库存不足 分页()
    Map<String,Object> listgoods();

}
