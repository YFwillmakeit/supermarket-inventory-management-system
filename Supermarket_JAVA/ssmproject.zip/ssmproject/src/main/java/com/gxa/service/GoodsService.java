package com.gxa.service;

import com.gxa.dto.ResultData;
import com.gxa.pojo.Goods;

import java.util.Date;
import java.util.List;
import java.util.Map;


public interface GoodsService {
    /*显示商品*/
    ResultData showGoods();
    /*增加商品*/
    ResultData addGoods(String goodsName, String name, String goodsDesc, Integer shelfLife, Date productTime);

    /*单行删除*/
    ResultData delGoods(int delId);

    /*修改商品*/
    ResultData editGoods(Integer id,String goodsName,String name,String goodsDesc,Integer shelfLife);

    /*搜索商品*/
    ResultData searchGoods(String goodsName);

    /*批量删除*/
    boolean delAllGoods(int[] allId);

}
