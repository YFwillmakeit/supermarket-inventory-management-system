package com.gxa.controller;

import com.gxa.pojo.User;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author:IT-CNLM
 * @date:Created at 2020/07/16
 */

@Api(tags = "测试接口")
@RestController
public class IndexController {

    @ApiOperation("首页接口")
    @GetMapping("/index")
    public String index(){
        return "Hello World!";
    }


    @ApiOperation("测试query传参")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "用户ID", required = true, paramType = "query", dataType = "int"),
            @ApiImplicitParam(name = "name", value = "用户名", required = true, paramType = "query", dataType = "String")
    })
    @GetMapping("/test/param/query")
    public String testParams(Integer id, String name){
        return "ID:"+id;
    }



    @ApiOperation("测试Form传参")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "用户ID", required = true, paramType = "form", dataType = "int"),
            @ApiImplicitParam(name = "name", value = "用户名", required = true, paramType = "form", dataType = "String")
    })
    @GetMapping("/test/param/form")
    public String testParamsFrom(Integer id, String name){
        return name+":"+id;
    }


    @ApiOperation("测试Path传参")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "name", value = "用户名", required = true, paramType = "path", dataType = "String"),
            @ApiImplicitParam(name = "age", value = "年龄", required = false, paramType = "path", dataType = "int"),
    })
    @PostMapping("/test/param/path/{name}/{age}")
    public String testParamsPath(@PathVariable String name, @PathVariable Integer age){
        return name+":"+age;
    }


    @ApiOperation("测试对象")
    @PostMapping("/test/object")
    public User testObject(User user){
        return user;
    }

}
