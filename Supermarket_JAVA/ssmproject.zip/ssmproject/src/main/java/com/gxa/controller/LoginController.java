package com.gxa.controller;

import com.gxa.dto.ResultData;
import com.gxa.pojo.User;
import com.gxa.service.UserService;
import com.gxa.utils.Code;
import com.gxa.utils.MD5Util;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.util.UUID;



@Api(tags = "登录")
@RestController
public class LoginController {

    @Autowired
    private UserService userService;

    /**
     * @param session
     * @param username 用户名
     * @param password 用户密码
     * @return
     */
    @ApiOperation("登录系统")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "username", value = "用户名", required = true, paramType = "query", dataType = "String"),
        @ApiImplicitParam(name = "password", value = "用户密码", required = true, paramType = "query", dataType = "String")
    })

    @PostMapping("/login")
    public ResultData login(HttpSession session,@RequestParam()String username,@RequestParam()String password){
        /*登录验证数据*/
        ResultData resultData=new ResultData();
        Code code=new Code();
        User user = new User();
        //对密码进行加密
        String passwordByMd5 = MD5Util.digest(password);
        user.setUsername(username);
        user.setPassword(passwordByMd5);
        user=userService.findusernamePassword(user.getUsername(),user.getPassword());

            if (user!=null){
                resultData.setCode(Code.SUCCESS);
                resultData.setMsg("登录成功");
                session.setAttribute("user",user);
                resultData.setData(user);
            }else{
                resultData.setCode(Code.FALISE);
                resultData.setMsg("用户名或者密码错误");
            }
        return resultData;
    }
}
