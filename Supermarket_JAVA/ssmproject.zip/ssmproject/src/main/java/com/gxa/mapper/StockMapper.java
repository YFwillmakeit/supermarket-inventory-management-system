package com.gxa.mapper;

import com.gxa.pojo.Stock;
import com.gxa.pojo.StockExample;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

public interface StockMapper {
    long countByExample(StockExample example);

    int deleteByExample(StockExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(Stock record);

    int insertSelective(Stock record);

    List<Stock> selectByExample(StockExample example);

    Stock selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") Stock record, @Param("example") StockExample example);

    int updateByExample(@Param("record") Stock record, @Param("example") StockExample example);

    int updateByPrimaryKeySelective(Stock record);

    int updateByPrimaryKey(Stock record);

    List<Stock> listStock();

    List<Map<String,Object>> stock(int param1, int param2);

    int stockCount();

    Map<String, Object> stockSearch(String goodsName);

    List<Map<String,Object>> check(@Param("type") int type,@Param("param1") int param1,@Param("param2") int param2);

    List<Map<String, Object>> checkSearch(int type, String goodsName,int page);

}