package com.gxa.controller;

import com.github.pagehelper.PageHelper;
import com.gxa.service.StockChangeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/**
 * 库存变动controller类
 */
@Api(tags = "即将过期")
@RestController
public class StockChangeController {

    @Autowired
    private StockChangeService stockChangeService;

    /**
     * @param pageNo 页数
     * @return
     */
    @ApiOperation("即将过期")
    @GetMapping("/change")
    public Map change(@RequestParam(defaultValue = "1")int pageNo){
        int limit=10;
        PageHelper.startPage(pageNo,limit);
        return stockChangeService.listgoods2();
    }

}
