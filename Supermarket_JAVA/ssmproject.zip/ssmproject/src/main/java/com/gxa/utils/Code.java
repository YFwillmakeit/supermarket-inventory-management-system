package com.gxa.utils;

/**
 * Created with IntelliJ IDEA.
 * User: tyg
 * Date: 2020/07/18 10:38
 * Version: V1.0
 * Description:
 */
public class Code {
    public static int SUCCESS = 200;
    public static int FALISE = 100;
}
