package com.gxa.service.impl;

import com.github.pagehelper.PageInfo;
import com.gxa.dto.ResultData;
import com.gxa.mapper.RoleMapper;
import com.gxa.mapper.RolePermissionMapper;
import com.gxa.pojo.Role;
import com.gxa.pojo.RolePermission;
import com.gxa.pojo.RolePermissionExample;
import com.gxa.service.RoleService;
import com.gxa.utils.Code;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: tyg
 * Date: 2020/07/18 20:05
 * Version: V1.0
 * Description:
 */
@Service
public class RoleServiceImpl implements RoleService {

    @Autowired
    RoleMapper roleMapper;

    @Autowired
    RolePermissionMapper rolePermissionMapper;

    @Override
    public ResultData listRole() {
        ResultData<Object> resultData = new ResultData<>();
        List<Role> roles = roleMapper.listRole();
        PageInfo<Role> pages = new PageInfo<>(roles, 3);
        resultData.setCode(200);
        HashMap<String, Object> map = new HashMap<>();
        map.put("total", pages.getTotal());
        map.put("pages", pages.getPages());
        map.put("pageNum", pages.getPageNum());
        map.put("userList", pages.getList());
        resultData.setData(map);
        return resultData;
    }

    @Override
    public ResultData insertRole(String roleName, List<Integer> permissionIdList) {
        ResultData<Object> resultData = new ResultData<>();
        Role role = new Role();
        role.setRolename(roleName);
        try {
            roleMapper.insertRole(role);
            System.out.println("添加的角色ID" + role.getId());
            for (int permissionId : permissionIdList) {
                RolePermission rolePermission = new RolePermission();
                rolePermission.setRoleId(role.getId());
                rolePermission.setPermissionId(permissionId);
                rolePermissionMapper.insertSelective(rolePermission);
            }
            resultData.setCode(Code.SUCCESS);
            resultData.setMsg("添加成功");
        } catch (RuntimeException e) {
            resultData.setCode(Code.FALISE);
            resultData.setMsg("添加失败");
            e.printStackTrace();
        }
        return resultData;
    }

    @Override
    public ResultData updateRole(List<Integer> permissionIdList, int roleId, String roleName) {
        ResultData<Object> resultData = new ResultData<>();

        try {
            // 修改角色名
            Role role = new Role();
            role.setRolename(roleName);
            role.setId(roleId);
            roleMapper.updateByPrimaryKeySelective(role);

            RolePermissionExample rolePermissionExample = new RolePermissionExample();
            //删除角色所有权限记录
            rolePermissionExample.createCriteria().andRoleIdEqualTo(roleId);
            rolePermissionMapper.deleteByExample(rolePermissionExample);

            // 从新为角色分配权限
            for (int permissionId : permissionIdList) {
                RolePermission rolePermission = new RolePermission();
                rolePermission.setRoleId(roleId);
                rolePermission.setPermissionId(permissionId);
                rolePermissionMapper.insertSelective(rolePermission);
            }
            resultData.setCode(Code.SUCCESS);
            resultData.setMsg("修改成功");
        } catch (Exception e) {
            resultData.setCode(Code.FALISE);
            resultData.setMsg("修改失败");
            e.printStackTrace();
        }
        return resultData;
    }

    @Override
    public ResultData deleteRole(int roleId) {
        ResultData<Object> resultData = new ResultData<>();
        int j = roleMapper.deleteByPrimaryKey(roleId);
        RolePermissionExample rolePermissionExample = new RolePermissionExample();
        rolePermissionExample.createCriteria().andRoleIdEqualTo(roleId);
        int i = rolePermissionMapper.deleteByExample(rolePermissionExample);
        resultData.setCode(Code.SUCCESS);
        resultData.setMsg("删除成功");
        return resultData;
    }

    @Override
    public ResultData listAllRole() {
        ResultData<Object> resultData = new ResultData<>();

        List<Role> roles = roleMapper.listRole();
        resultData.setCode(Code.SUCCESS);
        resultData.setData(roles);
        return resultData;
    }
}
