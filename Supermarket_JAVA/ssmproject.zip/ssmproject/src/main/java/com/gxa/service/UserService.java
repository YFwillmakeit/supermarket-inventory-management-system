package com.gxa.service;

import com.gxa.dto.ResultData;
import com.gxa.pojo.User;

import java.util.List;

public interface UserService {
    ResultData listUser();
    User findusernamePassword(String username, String password);
    ResultData insertUser(User user);
    ResultData removeUser(int userId);

    ResultData removeUserbyIdList(List<Integer> userIdlist);

    ResultData updateUser(User user);

    ResultData searchUser(User user);

}
