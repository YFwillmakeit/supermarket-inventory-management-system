package com.gxa.pojo;

public class Stock {
    private Integer id;

    private Integer goodsId;

    private Integer goodsAmount;

    private Integer standardAmount;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getGoodsId() {
        return goodsId;
    }

    public void setGoodsId(Integer goodsId) {
        this.goodsId = goodsId;
    }

    public Integer getGoodsAmount() {
        return goodsAmount;
    }

    public void setGoodsAmount(Integer goodsAmount) {
        this.goodsAmount = goodsAmount;
    }

    public Integer getStandardAmount() {
        return standardAmount;
    }

    public void setStandardAmount(Integer standardAmount) {
        this.standardAmount = standardAmount;
    }
}