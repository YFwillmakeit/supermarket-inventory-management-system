package com.gxa.controller;

import com.github.pagehelper.PageHelper;
import com.gxa.dto.ResultData;
import com.gxa.pojo.User;
import com.gxa.service.UserService;
import com.gxa.utils.Constant;
import com.gxa.utils.MD5Util;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.models.auth.In;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: tyg
 * Date: 2020/07/17 14:41
 * Version: V1.0
 * Description:
 */
@Api(tags = "员工管理")
@RestController
public class UserController {

    @Autowired
    private UserService userService;

    @ApiOperation("模块首页接口")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "pageNo", value = "页号", required = false, paramType = "query", dataType = "int")
    })
    @GetMapping("/user/show")
    public ResultData showUser(@RequestParam(defaultValue = "1") int pageNo) {
        // 通过线程绑定，查询到页面数据和页面信息 PageHelper.startPage(页号, 每页的数据条数);
        PageHelper.startPage(pageNo, Constant.LIMIT);
        return userService.listUser();
    }

    @ApiOperation("单个删除员工")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "userId", value = "员工id", required = true),
            @ApiImplicitParam(name = "pageNo", value = "页号", required = true)
    })
    @PostMapping("/user/delete")
    public ResultData removeUser(@RequestParam Integer userId, @RequestParam Integer pageNo) {
        ResultData resultData1 = userService.removeUser(userId);
        PageHelper.startPage(pageNo, 3);
        ResultData resultData = userService.listUser();
        resultData1.setData(resultData.getData());
        return resultData1;
    }

    @ApiOperation("添加员工")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "user", value = "员工对象", required = true)
    })
    @PostMapping("/user/add")
    public ResultData insertUser(@RequestBody User user) {
        System.out.println(user);
        return userService.insertUser(user);
    }

    @ApiOperation("批量删除")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "map", value = "json对象{userIdlist:[],pageNo:}", required = true),
    })
    @PostMapping("/user/beachDelete")
    public ResultData beachRemoveUser(@RequestBody Map<String, Object> map) {
        List<Integer> userIdlist = (ArrayList<Integer>) map.get("userIdlist");
        int pageNo = (int) map.get("pageNo");
        ResultData resultData1 = userService.removeUserbyIdList(userIdlist);
        PageHelper.startPage(pageNo, Constant.LIMIT);
        ResultData resultData = userService.listUser();
        resultData1.setData(resultData.getData());
        return resultData1;
    }

    @ApiOperation("员工修改")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "user", value = "员工json对象", required = true),
    })
    @PostMapping("/user/update")
    public ResultData updateUser(@RequestBody User user) {
        return userService.updateUser(user);
    }

    @ApiOperation("条件查询")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "data", value = "json对象{username:,roleId:,pageNo:}两个属性可以只传一个", required = true)
    })
    @PostMapping("/user/search")
    public ResultData searchUserByCondition(@RequestBody Map<String, Object> data) {
        String username = (String) data.get("username");
        Integer roleId = (Integer) data.get("roleId");
        User user = new User();
        if (username != null){
            user.setUsername(username);
        }
        if (roleId != null){
            user.setRoleId(roleId);
        }
        System.out.println(user);
        Integer pageNo = (Integer) data.get("pageNo");
        if (pageNo == null) {
            pageNo = 1;
        }
        PageHelper.startPage(pageNo, Constant.LIMIT);
        return userService.searchUser(user);
    }
}
