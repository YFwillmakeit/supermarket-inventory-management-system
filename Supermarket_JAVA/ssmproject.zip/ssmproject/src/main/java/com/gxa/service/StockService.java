package com.gxa.service;

import com.gxa.dto.ResultData;

import java.util.List;
import java.util.Map;

public interface StockService {
    Map<String, Object> stock(int page);

    List<Map<String, Object>> stockSearch(String goodsName);

    Map<String, Object> check(int type,int page);

    Map<String, Object> checkSearch(int type, String goodsName,int page);

    ResultData checkAdd(int i, Map<String, String> mapList, int id);

    ResultData checkEdit(int i, Map<String, String> mapList,int id);

    void checkDelete(int id,int userId);
}
