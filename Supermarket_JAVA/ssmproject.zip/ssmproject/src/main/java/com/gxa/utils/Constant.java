package com.gxa.utils;

/**
 * Created with IntelliJ IDEA.
 * User: tyg
 * Date: 2020/07/18 15:40
 * Version: V1.0
 * Description:
 */
public class Constant {
    /**
     * 分页查询每页显示的数量
     */
    public static int LIMIT = 10;

}
