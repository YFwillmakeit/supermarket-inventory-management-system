package com.gxa.service.impl;

import com.github.pagehelper.PageInfo;
import com.gxa.mapper.StockChangeMapper;
import com.gxa.mapper.StockMapper;
import com.gxa.pojo.Goods;
import com.gxa.service.StockChangeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class StockChangeServiceImpl implements StockChangeService {

    @Autowired
    private StockChangeMapper stockChangeMapper;

    /**
     * 商品即将
     * @return
     */
    @Override
    public Map<String, Object> listgoods2() {
        List<Map<String, Object>> list = stockChangeMapper.listStock2();
        PageInfo<Map<String, Object>> pages=new PageInfo<>(list,3);
        HashMap<String,Object> map=new HashMap<>();
        map.put("total",pages.getTotal());
        map.put("pages",pages.getPages());
        map.put("pagenum", pages.getPageNum());
        map.put("list",pages.getList());
        System.out.println(list);
        return map;
    }

    /**
     * 商品库存不足分页
     * @return
     */
    @Override
    public Map<String, Object> listgoods() {
        List<Map<String, Object>> list = stockChangeMapper.listStock1();
        PageInfo<Map<String, Object>> pages=new PageInfo<>(list,3);
        HashMap<String,Object> map=new HashMap<>();
        map.put("total",pages.getTotal());
        map.put("pages",pages.getPages());
        map.put("pagenum", pages.getPageNum());
        map.put("list",pages.getList());
        System.out.println(list);
        return map;
    }
}
