package com.gxa.controller;


import com.github.pagehelper.PageHelper;
import com.gxa.dto.ResultData;
import com.gxa.service.StatisticsService;
import com.gxa.utils.Code;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Map;

/**
 * 报表统计controller类
 */
@Api(tags = "报表统计接口")
@Controller
public class StatisticsController {

    @Autowired
    StatisticsService statisticsService;

    /**
     * 默认每页显示10条
     */
    private static final int DEFAULT_COUNT = 4;

    @ApiOperation("按时间分页查询出库记录或入库记录")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "typeCode", value = "出入库类型状态码（不限 0，入库 1 ，出库 2）", required = true, paramType = "query", dataType = "int"),
            @ApiImplicitParam(name = "dateCode", value = "时间类型状态码（不限 0，日 1，周 2，月 3）", required = true, paramType = "query", dataType = "int"),
            @ApiImplicitParam(name = "start", value = "获取数据的页码", required = true, paramType = "query", dataType = "int")
    })
    @GetMapping("/statistics/check/list")
    @ResponseBody
    public ResultData getStockChangeListByDateType(@RequestParam Integer typeCode,@RequestParam Integer dateCode, @RequestParam Integer start) {

        ResultData resultData = new ResultData();

        //请求数据完整进行查询
        if (start != null && typeCode != null && dateCode != null) {
            PageHelper.startPage(start, DEFAULT_COUNT);
            //查询结果
            Map<String, Object> map = statisticsService.getStockChangeListByDateType(typeCode, dateCode, start);
            resultData.setCode(Code.SUCCESS);
            resultData.setMsg("查询成功！");
            resultData.setData(map);
            return resultData;
        } else {
            //请求数据不完整返回请求错误
            resultData.setCode(Code.FALISE);
            resultData.setMsg("必须请求数据不完整！");
            resultData.setData(null);
            return resultData;
        }
    }

    @ApiOperation("按类型统计商品库存")
    @GetMapping("/statistics/stock")
    @ResponseBody
    public ResultData getStockStatistics() {
        ResultData resultData = new ResultData();
        resultData.setCode(Code.SUCCESS);
        resultData.setMsg("查询成功！");
        resultData.setData(statisticsService.getStockStatistics());
        return resultData;
    }

    @ApiOperation("统计一周内的出库总量与入库总量")
    @GetMapping("/statistics/check")
    @ResponseBody
    public ResultData getCheckStatistics() {
        ResultData resultData = new ResultData();
        resultData.setCode(Code.SUCCESS);
        resultData.setMsg("查询成功！");
        resultData.setData(statisticsService.getCheckinAndCheckoutStatistics());
        return resultData;
    }

}
