package com.gxa.mapper;

import com.gxa.pojo.StockChange;
import com.gxa.pojo.StockChangeExample;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

public interface StockChangeMapper {
    long countByExample(StockChangeExample example);

    int deleteByExample(StockChangeExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(StockChange record);

    int insertSelective(StockChange record);

    List<StockChange> selectByExample(StockChangeExample example);

    StockChange selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") StockChange record, @Param("example") StockChangeExample example);

    int updateByExample(@Param("record") StockChange record, @Param("example") StockChangeExample example);

    int updateByPrimaryKeySelective(StockChange record);

    int updateByPrimaryKey(StockChange record);
    List<Map<String,Object>> listStock1();
    List<Map<String,Object>> listStock2();

    int checkCount(int type,String goodsName);
}