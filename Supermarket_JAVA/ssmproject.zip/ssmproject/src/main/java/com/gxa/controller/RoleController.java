package com.gxa.controller;

import com.github.pagehelper.PageHelper;
import com.gxa.dto.ResultData;
import com.gxa.pojo.Role;
import com.gxa.service.RoleService;
import com.gxa.utils.Constant;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.RequestDataValueProcessor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: tyg
 * Date: 2020/07/18 20:04
 * Version: V1.0
 * Description:
 */
@Api(tags = "角色管理")
@RestController
public class RoleController {

    @Autowired
    RoleService roleService;

    @ApiOperation("模块首页接口")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "pageNo", value = "页号", required = false, paramType = "query", dataType = "int")
    })
    @GetMapping("/role/showRole")
    public ResultData show(@RequestParam(required = false, defaultValue = "1") int pageNo){
        PageHelper.startPage(pageNo,Constant.LIMIT);
        return roleService.listRole();
    }

    @ApiOperation("添加角色")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "data", value = "json对象{permissionIdList:[],roleName:}", required = true),
    })
    @PostMapping("/role/add")
    public ResultData addRole(@RequestBody Map<String, Object> data){
        ArrayList<Integer> permissionIdList = (ArrayList<Integer>)data.get("permissionIdList");
        String roleName = (String)data.get("roleName");
        ResultData resultData = roleService.insertRole(roleName, permissionIdList);
        return resultData;
    }

    @ApiOperation("角色修改")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "data", value = "json对象{permissionIdList:[],roleId:}", required = true),
    })
    @PostMapping("/role/update")
    public ResultData updateRole(@RequestBody Map<String, Object> data){
        ArrayList<Integer> permissionIdList = (ArrayList<Integer>)data.get("permissionIdList");
        int roleId = (int)data.get("roleId");
        String roleName = (String) data.get("rolename");
        return roleService.updateRole(permissionIdList, roleId,roleName);
    }

    @ApiOperation("删除角色")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "roleId", value = "角色ID", required = true, paramType = "query", dataType = "int"),
    })
    @GetMapping("/role/delete")
    public ResultData removeRole(int roleId){
        return roleService.deleteRole(roleId);
    }

    @ApiOperation("获取所有角色")
    @GetMapping("/role/showAllRole")
    public ResultData showAllRole(){
        return roleService.listAllRole();
    }

}
