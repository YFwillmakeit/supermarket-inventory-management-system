package com.gxa.controller;


import com.gxa.dto.ResultData;
import com.gxa.pojo.User;
import com.gxa.utils.Code;
import com.mysql.jdbc.Constants;
import io.swagger.annotations.Api;
import org.springframework.http.HttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import com.gxa.dto.ResultData;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import javax.servlet.http.HttpSession;



@Api(tags = "注销")
@RestController
public class LogoutController {

    /**
     * @param
     * @param session
     * @return resultData对象
     */
    @GetMapping("/logout")
    public ResultData  logout(HttpSession session) {
       ResultData resultData = new ResultData();
        if (session.getAttribute("user") == null){
            resultData.setCode(Code.FALISE);
            resultData.setMsg("注销失败");
            return resultData;
        }else {
            session.removeAttribute("user");
            resultData.setCode(Code.SUCCESS);
            resultData.setMsg("注销成功");
        }
    return resultData;
    }
}
