package com.gxa.pojo;

import javax.validation.constraints.*;
import java.util.Date;

public class Goods {
    private Integer id;

    @NotEmpty
    @Pattern(regexp ="^[\\u4e00-\\u9fa5]{0,}$")
    private String goodsName;

    private String goodsDesc;

    @Past
    private Date productTime;

    @Min(0)
    @Max(1000)
    private Integer shelfLife;

    @Min(0)
    @Max(7)
    private Integer typeId;

    @Min(0)
    @Max(1000)
    private Integer expirationTime;


    @Min(0)
    @Max(1)
    private Integer state;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getGoodsName() {
        return goodsName;
    }

    public void setGoodsName(String goodsName) {
        this.goodsName = goodsName == null ? null : goodsName.trim();
    }

    public String getGoodsDesc() {
        return goodsDesc;
    }

    public void setGoodsDesc(String goodsDesc) {
        this.goodsDesc = goodsDesc == null ? null : goodsDesc.trim();
    }

    public Date getProductTime() {
        return productTime;
    }

    public void setProductTime(Date productTime) {
        this.productTime = productTime;
    }

    public Integer getShelfLife() {
        return shelfLife;
    }

    public void setShelfLife(Integer shelfLife) {
        this.shelfLife = shelfLife;
    }

    public Integer getTypeId() {
        return typeId;
    }

    public void setTypeId(Integer typeId) {
        this.typeId = typeId;
    }

    public Integer getExpirationTime() {
        return expirationTime;
    }

    public void setExpirationTime(Integer expirationTime) {
        this.expirationTime = expirationTime;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }
}