package com.gxa.pojo.bean;

import java.sql.Date;


/**
 * 封装统计结果
 * id 库存变动id
 * goodsName 出入库商品名称
 * Name 出入库商品类型名称
 * amount 出入库数量
 * time 出入库时间
 * username 操作者用户名
 *
 *
 * @author Climber
 */
public class StatisticsStockChangeBean {

    private int id;

    private String goodsName;

    private String name;

    private int amount;

    private Date time;

    private String username;


    public StatisticsStockChangeBean() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getGoodsName() {
        return goodsName;
    }

    public void setGoodsName(String goodsName) {
        this.goodsName = goodsName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public String toString() {
        return "StatisticsStockChangeBean{" +
                "id=" + id +
                ", goodsName='" + goodsName + '\'' +
                ", Name='" + name + '\'' +
                ", amount=" + amount +
                ", time=" + time +
                ", username='" + username + '\'' +
                '}';
    }
}
